/**
 * @internal
 */
export declare const packageVersion = "19.8.0";
//# sourceMappingURL=version.d.ts.map