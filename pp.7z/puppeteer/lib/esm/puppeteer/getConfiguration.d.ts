import { Configuration } from 'puppeteer-core';
/**
 * @internal
 */
export declare const getConfiguration: () => Configuration;
//# sourceMappingURL=getConfiguration.d.ts.map