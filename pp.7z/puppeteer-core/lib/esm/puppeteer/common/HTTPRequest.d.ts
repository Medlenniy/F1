/**
 * Copyright 2020 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { Protocol } from 'devtools-protocol';
import { ContinueRequestOverrides, ErrorCode, HTTPRequest as BaseHTTPRequest, InterceptResolutionState, ResourceType, ResponseForRequest } from '../api/HTTPRequest.js';
import { HTTPResponse } from '../api/HTTPResponse.js';
import { CDPSession } from './Connection.js';
import { Frame } from './Frame.js';
/**
 * @internal
 */
export declare class HTTPRequest extends BaseHTTPRequest {
    #private;
    _requestId: string;
    _interceptionId: string | undefined;
    _failureText: string | null;
    _response: HTTPResponse | null;
    _fromMemoryCache: boolean;
    _redirectChain: HTTPRequest[];
    get client(): CDPSession;
    constructor(client: CDPSession, frame: Frame | null, interceptionId: string | undefined, allowInterception: boolean, event: Protocol.Network.RequestWillBeSentEvent, redirectChain: HTTPRequest[]);
    url(): string;
    continueRequestOverrides(): ContinueRequestOverrides;
    responseForRequest(): Partial<ResponseForRequest> | null;
    abortErrorReason(): Protocol.Network.ErrorReason | null;
    interceptResolutionState(): InterceptResolutionState;
    isInterceptResolutionHandled(): boolean;
    enqueueInterceptAction(pendingHandler: () => void | PromiseLike<unknown>): void;
    finalizeInterceptions(): Promise<void>;
    resourceType(): ResourceType;
    method(): string;
    postData(): string | undefined;
    headers(): Record<string, string>;
    response(): HTTPResponse | null;
    frame(): Frame | null;
    isNavigationRequest(): boolean;
    initiator(): Protocol.Network.Initiator;
    redirectChain(): HTTPRequest[];
    /**
     * Access information about the request's failure.
     *
     * @remarks
     *
     * @example
     *
     * Example of logging all failed requests:
     *
     * ```ts
     * page.on('requestfailed', request => {
     *   console.log(request.url() + ' ' + request.failure().errorText);
     * });
     * ```
     *
     * @returns `null` unless the request failed. If the request fails this can
     * return an object with `errorText` containing a human-readable error
     * message, e.g. `net::ERR_FAILED`. It is not guaranteed that there will be
     * failure text if the request fails.
     */
    failure(): {
        errorText: string;
    } | null;
    /**
     * Continues request with optional request overrides.
     *
     * @remarks
     *
     * To use this, request
     * interception should be enabled with {@link Page.setRequestInterception}.
     *
     * Exception is immediately thrown if the request interception is not enabled.
     *
     * @example
     *
     * ```ts
     * await page.setRequestInterception(true);
     * page.on('request', request => {
     *   // Override headers
     *   const headers = Object.assign({}, request.headers(), {
     *     foo: 'bar', // set "foo" header
     *     origin: undefined, // remove "origin" header
     *   });
     *   request.continue({headers});
     * });
     * ```
     *
     * @param overrides - optional overrides to apply to the request.
     * @param priority - If provided, intercept is resolved using
     * cooperative handling rules. Otherwise, intercept is resolved
     * immediately.
     */
    continue(overrides?: ContinueRequestOverrides, priority?: number): Promise<void>;
    respond(response: Partial<ResponseForRequest>, priority?: number): Promise<void>;
    abort(errorCode?: ErrorCode, priority?: number): Promise<void>;
}
//# sourceMappingURL=HTTPRequest.d.ts.map