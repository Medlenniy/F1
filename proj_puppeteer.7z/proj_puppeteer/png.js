// import puppeteer from 'puppeteer-core';

const puppeteer = require('puppeteer');

(async() => {

    const browser = await puppeteer.launch({
      headless: false,
      // See flags at https://peter.sh/experiments/chromium-command-line-switches/.
      args: [
        '--disable-infobars', // Removes the butter bar.
        '--start-maximized',
        // '--start-fullscreen',
        // '--window-size=1920,1080',
        // '--kiosk',
      ],
    });

    const page = await browser.newPage();
    await page.goto('https://nodejs.org/api/esm.html');

    await page.waitForSelector('.header-container');
    // await page.click('.MediaGrid__imageOld');
    
    await page.setViewport(
        { width: 1200, height: 800}
    )
    await page.screenshot({ path: 'test.png' });
    await browser.close();

    console.log('done');
})();
